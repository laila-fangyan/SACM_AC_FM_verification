This project contains system models of High voltage controller(HVC), and the AC generation/ FM verificaiton procedures(folders named with "number.xx").

Step 1: Metamodel register
	-SACM metamodel
	-Hazardlog metamodel
	-RoboChart metamodel
	
Step 2: AC generation by running X.lauch files in folders of "1.hazardlog 2 emf" and "emf hazardlog 2 AC"

Step 3: AC claim verificaiton by FDR model checking 
	-run X.lauch files in "3. Kapture SR to assertions" folder
	-run x.assertions files in "3. Kapture SR to assertions/ assertion_gen" by right click -RoboTool-CSP- Run
	- run X.lauch files in "4. evidence model generation from html" folder